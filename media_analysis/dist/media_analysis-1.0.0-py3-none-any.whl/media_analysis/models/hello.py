class Hello:
    def __init__(self):
        pass
    def info(self):
        return "Hello World"